These images are provided to assist the Salt community in creating
presentations or for use in sister projects to the Salt project.
